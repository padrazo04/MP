#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void  seleccion(int *v, int nEle, int (*comp)(int, int));
void  rellenarVector(int * v, int nEle);
void  imprimirVector(int* v, int nEle);
int*  reservarVector(int nEle);
int esMayor(int a, int b);
int esMenor(int a, int b);
int comparaEnteros(const void* e1, const void * e2);

int main()
{
	int nEle=10, *V1;
	int (*pf)(int, int);
	
	
	V1 = reservarVector(nEle);
	rellenarVector(V1, nEle);
	printf("\nVector V1 antes de ordenar:\n");
	imprimirVector(V1, nEle);
	
	seleccion(V1, nEle, &esMenor);
	printf("\nVector V1 despues de ordenar ascendente:\n");
	imprimirVector(V1, nEle);    

    pf = &esMayor;
	seleccion(V1, nEle, pf);
	printf("\nVector V1 despues de ordenar descendente:\n");
	imprimirVector(V1, nEle);
	
    
    rellenarVector(V1, nEle);
	printf("\nVector V1 antes de ordenar (quicksort):\n");
	imprimirVector(V1, nEle);
    qsort(V1, nEle, sizeof(int), &comparaEnteros);
	printf("\nVector V1 despues de ordenar (quicksort):\n");
	imprimirVector(V1, nEle);
	 
	int * ptr = (int*) bsearch(V1+4, V1, nEle, sizeof(int), &comparaEnteros);
    if(ptr!=NULL)
       printf("\nEl elemento %d esta en la posici�n %d", *ptr, ptr-V1);
    else
       printf("\nEle elemento no se encuentra en el vector");
	
	free(V1);
	return 0;
}

void  seleccion(int *v, int nEle, int (*comp)(int, int))
{
 int i, j;
 int pos, aux;
 
 for(i=0; i < nEle-1; i++)
  {
   pos = i;
    for(j= i+1; j < nEle; j++)
     {
      if ((*comp)(v[j],v[pos]))
       {
        pos = j;
       }
     }
   aux = v[pos];
   v[pos] = v[i];
   v[i] = aux;
  }
}

void rellenarVector(int* v, int nEle)
{
  int i;
  time_t t;
  	
  srand(time(&t)); 
  for (i = 0; i < nEle; i++)
  { 
     v[i] = rand()%51;
  }
}

void  imprimirVector(int* v, int nEle)
{
	int i;
	
	printf("[ ");
	for(i=0; i<nEle; i++)
	  printf("%d ", v[i]);
	printf("]");
}

int*  reservarVector(int nEle)
{
	return (int*) malloc(nEle*sizeof(int));
}

int esMayor(int a, int b)
{
	return a>b;
}
int esMenor(int a, int b)
{
	return a<b;
}

int comparaEnteros(const void* e1, const void * e2)
{
   int *a, *b;
   
   a = (int*) e1;
   b = (int*) e2;
   
   if(*a<*b)
     return -1;
   else
     if (*a == *b)
       return 0;
     else
       return 1;     
}


