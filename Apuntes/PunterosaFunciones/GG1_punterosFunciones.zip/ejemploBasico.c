#include <stdio.h>
int suma(int a, int b);
int resta(int a, int b);
int producto(int a, int b);
double sumaInversos(int n);
double sumaCuadrados(int n);
double inverso(int n);
double cuadrado(int n);
double sumaGenerica(int n, double (*ope)(int));



int main()
{
   int a=3, b=5;
   int (*operacion)(int, int);
   double (*pf)(int);  
      
   operacion = &suma;  
   printf("\n%d+%d=%d", a, b, suma(a, b));   
   printf("\n%d+%d=%d", a, b, (*operacion)(a, b)); 
   
   operacion = &resta;
   printf("\n%d-%d=%d", a, b, resta(a, b));  
   printf("\n%d-%d=%d", a, b, (*operacion)(a, b));     
   
   operacion = &producto;
   printf("\n%d*%d=%d", a, b, producto(a, b));
   printf("\n%d*%d=%d", a, b, (*operacion)(a, b));
   
   
   pf = &inverso;
   printf("\nSuma Inversos hasta 3: %lf", sumaInversos(3));
   printf("\nSuma Inversos hasta 3: %lf", sumaGenerica(3, &inverso));
   printf("\nSuma Inversos hasta 3: %lf", sumaGenerica(3, pf));
   
   
   pf = &cuadrado; 
   printf("\nSuma Cuadrados hasta 3: %lf", sumaCuadrados(3));
   printf("\nSuma Cuadrados hasta 3: %lf", sumaGenerica(3, &cuadrado));
   printf("\nSuma Cuadrados hasta 3: %lf", sumaGenerica(3, pf));
   
   
}


int suma(int a, int b)
{
 return a +b;
}    
 
int resta(int a, int b)
{
 return a - b;
}    

int producto(int a, int b)
{
 return a*b;
}

double sumaInversos(int n)
{
   double sum = 0;
   int i;
   
   for(i=1; i<=n; i++)
      sum+= 1.0/i;
   
   return sum;    
}

double sumaCuadrados(int n)
{
   double sum = 0;
   int i;
   
   for(i=1; i<=n; i++)
      sum+= i*i;
   
   return sum;    
}

double sumaGenerica(int n, double (*ope)(int))
{
   double sum = 0;
   int i;
   
   for(i=1; i<=n; i++)
      sum+= (*ope)(i);
   
   return sum;     
       
}


double inverso(int n)
{ 
   return 1.0/n;
}

double cuadrado(int n)
{
   return n*n;       
}


