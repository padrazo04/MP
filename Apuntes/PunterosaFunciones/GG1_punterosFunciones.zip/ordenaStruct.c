#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct cliente
{
  char nombre[100];
  float saldo;      
};

void rellenarVector(struct cliente* V, int nEle);
void escribirVector(struct cliente* V, int nEle);
struct cliente* reservarVector(int nEle);
void liberarVector(struct cliente** V);
int comparaNombres(struct cliente a, struct cliente b);
int comparaSaldos(struct cliente a, struct cliente b);
int comparaSaldosQuick(const void* e1, const void* e2);

void  seleccion(struct cliente *V, int nEle, int (*comp)(struct cliente, struct cliente));



int main()
{
    struct cliente *V;
    int nEle = 5;
    
    V= reservarVector(nEle);
    rellenarVector(V, nEle);
    
    printf("\nVector antes de seleccion:");
    escribirVector(V, nEle); 

    printf("\nVector despues de seleccion (nombres ascendente):");
    seleccion(V, nEle, &comparaNombres);
    escribirVector(V, nEle); 
        
    printf("\nVector despues de seleccion (saldos descendente):");
    seleccion(V, nEle, &comparaSaldos);
    escribirVector(V, nEle); 
    
    printf("\nVector despues de quicksort (saldos descendente):");    
    qsort(V, nEle, sizeof(struct cliente), &comparaSaldosQuick);    
    escribirVector(V, nEle);   
    
    liberarVector(&V);    
}


void rellenarVector(struct cliente* V, int nEle)
{
    int i;
    for(i=0; i<nEle; i++)
    {
       printf("V[%d].nombre: ", i);  
       scanf("%s", V[i].nombre);
       
       printf("V[%d].saldo: ", i);
       scanf("%f", &V[i].saldo);      
    }   
}

void escribirVector(struct cliente* V, int nEle)
{
    int i;
    for(i=0; i<nEle; i++)
    {
       printf("\nV[%d].nombre: <%s>", i, V[i].nombre);
       printf("\nV[%d].saldo: %f", i, V[i].saldo);
    } 
}

struct cliente* reservarVector(int nEle)
{
    return (struct cliente*)malloc(nEle*sizeof(struct cliente));      
}

void liberarVector(struct cliente** V)
{
    free(*V);
    *V = NULL;     
}


int comparaNombres(struct cliente a, struct cliente b)
{
   if (strcmp(a.nombre, b.nombre)<0)
     return 1;
   else
     return 0;  
     
}

int comparaSaldos(struct cliente a, struct cliente b)
{
   if(a.saldo>b.saldo)
     return 1;
   else
     return 0;   
}

int comparaSaldosQuick(const void* e1, const void* e2)
{
     struct cliente * a;
     struct cliente * b;
     
     a = (struct cliente*) e1;
     b = (struct cliente*) e2;
     
     if(a->saldo<b->saldo)
       return -1;
     else
       if(a->saldo>b->saldo)
         return 1;
       else
         return 0;        
}

void  seleccion(struct cliente *v, int nEle, int (*comp)(struct cliente, struct cliente))
{
 int i, j;
 int pos;
 struct cliente aux;
 
 for(i=0; i < nEle-1; i++)
  {
   pos = i;
    for(j= i+1; j < nEle; j++)
     {
      if ((*comp)(v[j],v[pos]))
       {
        pos = j;
       }
     }
   aux = v[pos];
   v[pos] = v[i];
   v[i] = aux;
  }
}

